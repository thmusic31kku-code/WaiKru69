/**
 * ตัวช่วยเรียก Google Apps Script Web App API
 * หมายเหตุสำคัญ: Apps Script ไม่รองรับ CORS preflight (OPTIONS)
 * ดังนั้น POST ทุกครั้งต้องส่งด้วย Content-Type: text/plain เพื่อเลี่ยง preflight
 * (เนื้อหาจริงยังคงเป็น JSON string — ฝั่ง Code.gs จะ parse เอง)
 */
const Api = (function () {
  const BASE_URL = window.APP_CONFIG.API_URL;

  async function get(action, params) {
    const query = new URLSearchParams(Object.assign({ action: action }, params || {}));
    const res = await fetch(BASE_URL + '?' + query.toString(), { method: 'GET' });
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'เกิดข้อผิดพลาดไม่ทราบสาเหตุ');
    return json.data;
  }

  async function post(action, payload) {
    const res = await fetch(BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(Object.assign({ action: action }, payload || {}))
    });
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'เกิดข้อผิดพลาดไม่ทราบสาเหตุ');
    return json.data;
  }

  return { get: get, post: post };
})();