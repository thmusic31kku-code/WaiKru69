/** ตรรกะหน้าร่วมทำบุญ: อัปโหลดสลิป (แปลงเป็น base64) และส่งข้อมูลไป Apps Script */

let slipBase64 = '';
let slipMimeType = '';

const fileDrop = document.getElementById('fileDrop');
const fileInput = document.getElementById('slipFile');
const filePreview = document.getElementById('filePreview');
const fileDropLabel = document.getElementById('fileDropLabel');

fileDrop.addEventListener('click', function () { fileInput.click(); });

fileInput.addEventListener('change', function () {
  const file = fileInput.files[0];
  if (!file) return;
  slipMimeType = file.type;
  const reader = new FileReader();
  reader.onload = function (e) {
    slipBase64 = e.target.result; // data URL รวม prefix "data:image/...;base64,"
    filePreview.src = slipBase64;
    filePreview.style.display = 'block';
    fileDropLabel.textContent = 'เลือกไฟล์แล้ว: ' + file.name + ' (คลิกเพื่อเปลี่ยน)';
    fileDrop.classList.add('has-file');
  };
  reader.readAsDataURL(file);
});

function showAlert(message, type) {
  document.getElementById('donateAlert').innerHTML =
    '<div class="alert alert-' + type + '">' + message + '</div>';
}

async function loadBankInfo() {
  const fields = ['bankName', 'bankAccName', 'bankAccNo'].map(function (id) { return document.getElementById(id); });
  try {
    const info = await Api.get('getEventInfo');
    document.getElementById('bankName').textContent = info.bank.bankName;
    document.getElementById('bankAccName').textContent = info.bank.accountName;
    document.getElementById('bankAccNo').textContent = info.bank.accountNo;
  } catch (e) {
    console.warn('โหลดข้อมูลบัญชีไม่สำเร็จ (ใช้ค่าตั้งต้นแทน):', e.message);
  } finally {
    fields.forEach(function (el) { if (el) el.classList.remove('skeleton'); });
  }
}
loadBankInfo();

document.getElementById('donateForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  if (!slipBase64) { showAlert('กรุณาแนบไฟล์สลิปการโอนเงินก่อนส่งข้อมูล', 'error'); return; }

  const btn = document.getElementById('donateSubmitBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> กำลังส่งข้อมูล...';

  try {
    const result = await Api.post('donate', {
      donor_name: document.getElementById('donorName').value.trim(),
      donor_phone: document.getElementById('donorPhone').value.trim(),
      donor_email: document.getElementById('donorEmail').value.trim(),
      amount: Number(document.getElementById('amount').value),
      note: document.getElementById('note').value.trim(),
      slip_base64: slipBase64,
      slip_mime_type: slipMimeType
    });
    showAlert('ขอบพระคุณสำหรับการทำบุญ! บันทึกข้อมูลเรียบร้อย (เลขที่อ้างอิง ' + result.id + ') ทีมงานจะตรวจสอบยอดโอนโดยเร็ว', 'success');
    document.getElementById('donateForm').reset();
    filePreview.style.display = 'none';
    fileDropLabel.textContent = 'คลิกเพื่อเลือกไฟล์ภาพสลิป (JPG/PNG)';
    fileDrop.classList.remove('has-file');
    slipBase64 = '';
  } catch (err) {
    showAlert('เกิดข้อผิดพลาด: ' + err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'ส่งข้อมูลการทำบุญ';
  }
});