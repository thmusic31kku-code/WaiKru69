/**
 * ตัวช่วย UI ที่ใช้ร่วมกันทุกหน้า: ซ่อนหน้าจอ loading, เปิด/ปิดเมนูมือถือ,
 * FAQ accordion และ scroll-reveal (แสดงองค์ประกอบแบบ fade-up เมื่อเลื่อนเข้ามาในจอ)
 */
(function () {
  // ---------- page loader ----------
  // แสดงอย่างน้อย MIN_VISIBLE_MS เพื่อไม่ให้กระพริบเร็วเกินไปบนเครื่อง/เน็ตที่ไวมาก
  var MIN_VISIBLE_MS = 450;
  var startedAt = Date.now();

  function hideLoader() {
    var loader = document.getElementById('pageLoader');
    var elapsed = Date.now() - startedAt;
    var wait = Math.max(0, MIN_VISIBLE_MS - elapsed);
    setTimeout(function () {
      if (loader) loader.classList.add('is-hidden');
      document.body.classList.remove('is-loading');
    }, wait);
  }

  if (document.readyState === 'complete') {
    hideLoader();
  } else {
    window.addEventListener('load', hideLoader);
    // กันไว้เผื่อบางทรัพยากร (เช่นรูปภาพภายนอก) โหลดช้าผิดปกติ
    setTimeout(hideLoader, 4000);
  }

  // ---------- mobile nav toggle ----------
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { navLinks.classList.remove('open'); });
    });
  }

  // ---------- FAQ accordion (no-op on pages without .faq-q) ----------
  document.querySelectorAll('.faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.parentElement;
      var isOpen = item.classList.toggle('open');
      btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  });

  // ---------- scroll reveal ----------
  var revealTargets = document.querySelectorAll('.reveal, .reveal-stagger');
  if (revealTargets.length) {
    if ('IntersectionObserver' in window) {
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
      revealTargets.forEach(function (el) { observer.observe(el); });
    } else {
      // เบราว์เซอร์เก่าที่ไม่รองรับ IntersectionObserver: แสดงผลทันที
      revealTargets.forEach(function (el) { el.classList.add('in-view'); });
    }
  }
})();