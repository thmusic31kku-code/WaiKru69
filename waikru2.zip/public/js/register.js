/** ตรรกะหน้าลงทะเบียน: Google Sign-In, ตัวนับการครอบครู, คำนวณยอดรวม, ส่งแบบตอบรับ */

const KHROB_ITEMS = [
  { key: 'ching', label: 'ครอบฉิ่ง' },
  { key: 'sathukan', label: 'สาธุการ' },
  { key: 'tra_hom_roeng', label: 'ตระโหมโรง' },
  { key: 'krabong_kan', label: 'กระบองกัน' },
  { key: 'bat_sakunee', label: 'บาทสกุณี' }
];

let eventInfo = null;
let khrobCounts = { ching: 0, sathukan: 0, tra_hom_roeng: 0, krabong_kan: 0, bat_sakunee: 0 };

function renderKhrobList() {
  const container = document.getElementById('khrobList');
  container.innerHTML = KHROB_ITEMS.map(function (item) {
    const price = eventInfo.prices[item.key];
    return '<div class="khrob-item">' +
      '<div><strong>' + item.label + '</strong><div class="hint">เงินกำนล ' + price.toLocaleString('th-TH') + ' บาท/คน</div></div>' +
      '<div class="qty-control">' +
      '<button type="button" data-key="' + item.key + '" data-dir="-1">−</button>' +
      '<span id="qty_' + item.key + '">0</span>' +
      '<button type="button" data-key="' + item.key + '" data-dir="1">+</button>' +
      '</div></div>';
  }).join('');

  container.querySelectorAll('button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const key = btn.dataset.key;
      const dir = Number(btn.dataset.dir);
      khrobCounts[key] = Math.max(0, khrobCounts[key] + dir);
      document.getElementById('qty_' + key).textContent = khrobCounts[key];
      updateTotal();
    });
  });
}

function updateTotal() {
  let khanCount = 0;
  let total = 0;
  KHROB_ITEMS.forEach(function (item) {
    const count = khrobCounts[item.key];
    khanCount += count;
    total += count * eventInfo.prices[item.key];
  });
  total += khanCount * eventInfo.prices.khan;
  document.getElementById('totalAmount').textContent = '฿ ' + total.toLocaleString('th-TH');
}

function showAlert(message, type) {
  document.getElementById('registerAlert').innerHTML = '<div class="alert alert-' + type + '">' + message + '</div>';
}

async function checkExistingRegistration(user) {
  try {
    const regs = await Api.get('getMyRegistration', { email: user.email, idToken: user.idToken });
    if (regs && regs.length) {
      const r = regs[regs.length - 1];
      document.getElementById('alreadyRegisteredView').style.display = 'block';
      document.getElementById('alreadyRegisteredView').innerHTML =
        '<div class="card" style="margin-bottom:24px;">' +
        '<h3>ท่านลงทะเบียนไว้แล้ว ✅</h3>' +
        '<p>เลขที่ใบตอบรับ: <strong>' + r.id + '</strong> | สถาบัน: ' + r.institution + '</p>' +
        '<p>ที่นั่งที่จอง: <strong>' + r.seat_numbers + '</strong></p>' +
        '<p>ยอดเงินกำนลโดยประมาณ: <strong>฿' + Number(r.total_amount).toLocaleString('th-TH') + '</strong></p>' +
        (r.pdf_url ? '<a class="btn btn-primary" href="' + r.pdf_url + '" target="_blank" rel="noopener">ดาวน์โหลดใบยืนยัน PDF</a>' : '<p class="hint">ใบยืนยัน PDF กำลังถูกสร้าง กรุณารีเฟรชภายหลัง</p>') +
        '</div>';
      document.getElementById('registerForm').style.display = 'none';
    }
  } catch (e) {
    console.warn('ตรวจสอบการลงทะเบียนเดิมไม่สำเร็จ:', e.message);
  }
}

async function onSignIn(user) {
  document.getElementById('signedOutView').style.display = 'none';
  document.getElementById('signedInView').style.display = 'block';
  document.getElementById('userName').textContent = user.name;
  document.getElementById('userPicture').src = user.picture;
  await checkExistingRegistration(user);
}

document.getElementById('signOutBtn').addEventListener('click', function () {
  GoogleAuth.signOut();
  location.reload();
});

document.getElementById('registerForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const user = GoogleAuth.getUser();
  if (!user) { showAlert('กรุณาเข้าสู่ระบบก่อน', 'error'); return; }

  const studentsCount = Number(document.getElementById('studentsCount').value || 0);
  const teachersCount = Number(document.getElementById('teachersCount').value || 0);
  if (studentsCount + teachersCount <= 0) {
    showAlert('กรุณาระบุจำนวนผู้เข้าร่วมอย่างน้อย 1 คน', 'error');
    return;
  }

  const btn = document.getElementById('registerSubmitBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> กำลังสำรองที่นั่งและสร้างใบยืนยัน...';

  try {
    const result = await Api.post('register', {
      idToken: user.idToken,
      institution: document.getElementById('institution').value.trim(),
      address: document.getElementById('address').value.trim(),
      coordinator_name: document.getElementById('coordinatorName').value.trim(),
      coordinator_phone: document.getElementById('coordinatorPhone').value.trim(),
      students_count: studentsCount,
      teachers_count: teachersCount,
      khrob_khru: khrobCounts
    });

    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('alreadyRegisteredView').style.display = 'block';
    document.getElementById('alreadyRegisteredView').innerHTML =
      '<div class="card center">' +
      '<h3>ลงทะเบียนสำเร็จ 🎉</h3>' +
      '<p>เลขที่ใบตอบรับ: <strong>' + result.id + '</strong></p>' +
      '<p>ที่นั่งที่จอง: <strong>' + result.seatNumbers.join(', ') + '</strong></p>' +
      '<p>ยอดเงินกำนลโดยประมาณ: <strong>฿' + Number(result.totalAmount).toLocaleString('th-TH') + '</strong></p>' +
      (result.pdfUrl ? '<a class="btn btn-primary" href="' + result.pdfUrl + '" target="_blank" rel="noopener">ดาวน์โหลดใบยืนยัน PDF พร้อม QR</a>' : '<p class="hint">ใบยืนยัน PDF กำลังถูกสร้าง กรุณารีเฟรชหน้าภายหลัง</p>') +
      '</div>';
  } catch (err) {
    showAlert('เกิดข้อผิดพลาด: ' + err.message, 'error');
    btn.disabled = false;
    btn.textContent = 'ส่งแบบตอบรับ & สำรองที่นั่ง';
  }
});

async function init() {
  try {
    eventInfo = await Api.get('getEventInfo');
  } catch (e) {
    console.error('โหลดข้อมูลงานไม่สำเร็จ:', e.message);
    eventInfo = { prices: { ching: 36, sathukan: 36, tra_hom_roeng: 36, krabong_kan: 109, bat_sakunee: 509, khan: 59 } };
  }
  renderKhrobList();

  // รอ Google Identity Services โหลดเสร็จก่อน initialize
  const waitForGoogle = setInterval(function () {
    if (window.google && window.google.accounts) {
      clearInterval(waitForGoogle);
      GoogleAuth.init(onSignIn);
      GoogleAuth.renderButton('gsiButton');
    }
  }, 200);
}

init();